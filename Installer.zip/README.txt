ProfitTrailer Installer and Updater Script for Ubuntu V.0.1 by @T1M3C

Instructions:

Edit config.cfg and add your API keys.
Upload installer.sh and config.cfg files to server home directory (via sftp)
Login and type in terminal:

Chmod +x install.sh
./install.sh

Follow the white rabbit.

