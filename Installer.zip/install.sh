#!/bin/bash

source ./config.cfg

echo ""
echo ""
echo "ProfitTrailer Installer and Updater Script for Ubuntu V.0.1 by @T1M3C"
echo ""
echo "------------------------------------------------------------------------------------------"
echo "Enter 1 to Install ProfitTrailer or 2 to upgrade ProfitTrailer."
echo "------------------------------------------------------------------------------------------"
ip=$(ip addr | grep 'state UP' -A2 | tail -n1 | awk '{print $2}' | cut -f1  -d'/')
read option
if [ "$option" = 1 ];
then
echo ""
echo "------------------------------------------------------------------------------------------"
echo "Please wait a few minutes for the end of installation, take a cup of tea and relax..."
echo "------------------------------------------------------------------------------------------"
echo ""
sudo apt-get update -y
sudo apt-get upgrade -y

sudo apt-get install -y default-jre git build-essential curl openssl libssl-dev unzip nodejs npm mc
sudo npm install --no-optional pm2 -g
cd /opt
wget $(curl -s https://api.github.com/repos/taniman/profit-trailer/releases/latest | grep 'browser_download_url' | cut -d\" -f4)
unzip ProfitTrailer.zip
rm ProfitTrailer.zip
cd /opt/ProfitTrailer

elif [ "$option" = 2 ];
then
    cd /opt
    wget $(curl -s https://api.github.com/repos/taniman/profit-trailer/releases/latest | grep 'browser_download_url' | cut -d\" -f4)
    unzip -j "/opt/ProfitTrailer.zip" "ProfitTrailer/ProfitTrailer.jar" -d "/tmp"
    rm ProfitTrailer.zip
    pm2 stop all
    find . -name "ProfitTrailer.jar" -exec cp /tmp/ProfitTrailer.jar {} \;
    rm /tmp/ProfitTrailer.jar
    pm2 start all
echo ""	
echo "------------------------------------------------------------------------------------------"
echo "Upgrade completed! All PT Instances upgraded successfully!"
echo "------------------------------------------------------------------------------------------"
echo ""
exit
fi
echo ""
echo "------------------------------------------------------------------------------------------"
echo "ProfitTrailer Installed to /opt/ProfitTrailer directory."
echo "Now we will configure basic settings and run it."
echo "Enter 1 for POLONIEX, 2 for BITTREX, 3 for BINANCE 4 for EXIT (I'll configure by myself.)"
echo "------------------------------------------------------------------------------------------"
read option2
if [ "$option2" -eq 1 ];
then

apikey1=$poloniex_apikey1
apisecret1=$poloniex_apisecret1
apikey2=$poloniex_apikey2
apisecret2=$poloniex_apisecret2

    while read a ; do echo ${a//trading.exchange =/trading.exchange = POLONIEX} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
    while read a ; do echo ${a//default_apiKey =/default_apiKey = "$apikey1"} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
    while read a ; do echo ${a//default_apiSecret =/default_apiSecret = "$apisecret1"} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
    while read a ; do echo ${a//trading_apiKey =/trading_apiKey = "$apikey2"} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
    echo "trading_apiSecret = $apisecret2" >> /opt/ProfitTrailer/application.properties
    echo ""
    echo "------------------------------------------------------------------------------------------"
    echo "Starting ProfitTrailer..."
    echo "------------------------------------------------------------------------------------------"
    pm2 start pm2-ProfitTrailer.json
    pm2 save
    pm2 startup
    echo ""
    echo ""
    echo "------------------------------------------------------------------------------------------"
    echo "Installation complete!"
    echo "Now you can access your ProfitTrailer via this link http://$ip:8081"
    echo "------------------------------------------------------------------------------------------"
    echo ""
elif [ "$option2" -eq 2 ];
then

apikey1=$bittrex_apikey1
apisecret1=$bittrex_apisecret1
apikey2=$bittrex_apikey2
apisecret2=$bittrex_apisecret2

    while read a ; do echo ${a//trading.exchange =/trading.exchange = BITTREX} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
    while read a ; do echo ${a//default_apiKey =/default_apiKey = "$apikey1"} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
    while read a ; do echo ${a//default_apiSecret =/default_apiSecret = "$apisecret1"} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
    while read a ; do echo ${a//trading_apiKey =/trading_apiKey = "$apikey2"} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
    echo "trading_apiSecret = $apisecret2" >> /opt/ProfitTrailer/application.properties
    echo ""
    echo "------------------------------------------------------------------------------------------"
    echo "Starting ProfitTrailer..."
    echo "------------------------------------------------------------------------------------------"
    pm2 start pm2-ProfitTrailer.json
    pm2 save
    pm2 startup
    echo ""
    echo ""
    echo "------------------------------------------------------------------------------------------"
    echo "Installation complete!"
    echo "Now you can access your ProfitTrailer via this link http://$ip:8081"
    echo "------------------------------------------------------------------------------------------"
    echo ""
elif [ "$option2" -eq 3 ];
then

apikey1=$binance_apikey1
apisecret1=$binance_apisecret1
apikey2=$binance_apikey2
apisecret2=$binance_apisecret2


	while read a ; do echo ${a//trading.exchange =/trading.exchange = BINANCE} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
	while read a ; do echo ${a//default_apiKey =/default_apiKey = "$apikey1"} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
	while read a ; do echo ${a//default_apiSecret =/default_apiSecret = "$apisecret1"} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
	while read a ; do echo ${a//trading_apiKey =/trading_apiKey = "$apikey2"} ; done < /opt/ProfitTrailer/application.properties > /opt/ProfitTrailer/application.properties.t ; mv /opt/ProfitTrailer/application.properties{.t,}
	echo "trading_apiSecret = $apisecret2" >> /opt/ProfitTrailer/application.properties
	echo ""
	echo "------------------------------------------------------------------------------------------"
	echo "Starting ProfitTrailer..."
	echo "------------------------------------------------------------------------------------------"
	pm2 start pm2-ProfitTrailer.json
	pm2 save
	pm2 startup
	echo ""
	echo ""
	echo "------------------------------------------------------------------------------------------"
	echo "Installation complete!"
	echo "Now you can access your ProfitTrailer via this link http://$ip:8081"
	echo "------------------------------------------------------------------------------------------"
	echo ""
fi
